package com.ddlab.rnd.type4;
//Adaptee
public interface CSVFormatter {
	
	String formatCSV(String text);

}
