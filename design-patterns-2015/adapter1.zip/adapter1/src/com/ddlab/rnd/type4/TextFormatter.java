package com.ddlab.rnd.type4;
//Target
public interface TextFormatter {
	
	String formatText(String text);

}
