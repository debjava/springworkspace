package com.ddlab.rnd.type3;

public interface TextFormattable {
 
    String formatText(String text);
}