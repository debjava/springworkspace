package com.ddlab.rnd.type3;

public interface CsvFormattable {
    String formatCsvText(String text);
}