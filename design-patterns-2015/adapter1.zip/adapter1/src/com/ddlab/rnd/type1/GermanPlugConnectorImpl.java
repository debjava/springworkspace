package com.ddlab.rnd.type1;

/**
 * Created by dmishra on 11/16/2015.
 */
public class GermanPlugConnectorImpl implements GermanPlugConnector {

    @Override
    public void giveElectricity() {

        System.out.println("German giving electricity ...");
    }
}
