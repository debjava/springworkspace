package com.ddlab.rnd.type1;

public interface GermanPlugConnector {

    public void giveElectricity();
} 