package com.ddlab.rnd.type1;

public interface UKPlugConnector {

    public void provideElectricity();
} 