package com.ddlab.rnd.type2;

public interface Device {
    public void getCharge(String charger);
}