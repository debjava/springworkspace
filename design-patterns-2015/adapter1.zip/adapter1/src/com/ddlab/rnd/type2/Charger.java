package com.ddlab.rnd.type2;

public interface Charger {
    public void chargeDevice(String charger);

    public String getCharger();
}
